# PySprout Interactive Six-Screen Prototype Plan

## Goal
Build a polished, mobile-first Python-learning web app for teen and adult beginners. The prototype should feel like a friendly forest quest: playful and encouraging without feeling childish, visually inspired by the uploaded HackRU artwork’s layered woodland atmosphere, chunky shapes, luminous accents, and cute guide character, but using entirely original branding and artwork.

The app will be called **PySprout**, with **Pip** as an original small seedling/forest-spirit guide. The prototype will demonstrate one coherent learning journey from dashboard to lesson to coding challenge, while making all six screens reachable and meaningfully interactive.

## Success Criteria
- Six distinct, navigable screens: Home, Course Map, Lesson, Code Challenge, Progress, and Profile.
- One end-to-end learning flow works: resume from Home, read the Variables lesson, answer a knowledge check, open the Code Challenge, run/submit a solution, and see success/progress feedback.
- Navigation and controls work without page reloads.
- The experience is optimized for narrow mobile viewports and expands cleanly on tablet/desktop.
- Visual design is cohesive, highly rounded, accessible, and clearly inspired by an enchanted forest rather than copying the supplied HackRU asset.
- Pip appears in several contextual poses or expressions using original inline SVG/CSS illustration variants.
- No backend, authentication service, external code runner, or persistence is required; all interactions use local React state and deterministic mock behavior.

## Product and Visual Direction

### Brand
- Product name: **PySprout**.
- Tagline: **Grow your Python skills, one quest at a time.**
- Mascot: **Pip**, a round seedling-like forest guide with leaf ears/sprout, large expressive eyes, rosy cheeks, and a tiny satchel. Variants: welcoming, thinking, cheering, and celebrating.
- Do not embed or redraw the uploaded HackRU logo, text, mushroom character, or exact scene. Treat it only as inspiration for atmosphere, depth, color contrast, and playful game-like framing.

### Design language
- Warm parchment/cream base with deep evergreen text.
- Forest green as the primary action color, lime/mint as progress accents, golden yellow for rewards, and coral/red only for warnings or streak emphasis.
- Layered leaf silhouettes and soft radial glows create woodland depth without using photography.
- 18–24px card radii, pill controls, tactile borders, soft offset shadows, and clear pressed/hover states.
- Friendly rounded typography using public Google font **Nunito** (with a system rounded fallback), with a heavier display weight for headings.
- Original inline SVG icons and illustrations so no new icon or image dependency is needed.
- Respect `prefers-reduced-motion`; motion is decorative and brief, never required to understand state.

## Information Architecture and Screens

### 1. Home / Dashboard
Purpose: Orient the learner and provide the clearest next action.

Content:
- Compact top bar with PySprout wordmark, current streak, and avatar button.
- Greeting: “Good afternoon, Maya” and Pip in a welcoming pose.
- “Continue your quest” hero card for **Python Foundations · Variables & Types**, showing lesson progress and an estimated 8 minutes.
- Primary **Continue lesson** action.
- Three small stats: current streak, XP, and lessons completed.
- “Today’s quests” list with lesson, challenge, and review states.
- Small motivational helper bubble from Pip.

Interactions:
- Continue lesson opens the Lesson screen.
- Today’s challenge opens the Code Challenge.
- Avatar opens Profile.
- Bottom navigation opens Home, Course Map, and Progress; a central emphasized play/learn action opens the current Lesson.

### 2. Course Map
Purpose: Show curriculum structure and progression.

Content:
- Header with course title and overall completion.
- A winding vertical forest path with chapter nodes connected by a dotted vine.
- Chapter 1, **Python Foundations**, expanded with nodes for Hello, Python; Variables & Types; Strings; and Mini Challenge.
- Later chapters shown as locked: Decisions, Loops, Functions, and Tiny Projects.
- Current Variables node is visually emphasized; completed and locked states are distinct.
- Pip points toward the next node.

Interactions:
- Completed/current nodes are selectable.
- Variables opens the Lesson.
- Mini Challenge opens the Code Challenge.
- Locked nodes show a small non-blocking “Finish the previous quest first” toast/helper message.

### 3. Lesson — Variables & Types
Purpose: Present a short, digestible lesson and check understanding.

Content:
- Back button, lesson label, and segmented lesson progress.
- Lesson heading: **Give your data a name**.
- Short explanation of variables with an everyday “labeled jar” analogy.
- Styled code example showing `player_name = "Maya"` and `level = 1`, with simple syntax coloring.
- Three type chips: string, integer, boolean.
- Pip in a thinking pose with a concise tip.
- Knowledge check: “Which variable stores a number?” with three answer cards.
- Sticky/mobile-safe **Check answer** action.

Interactions:
- Selecting an answer updates its state.
- Check answer displays accessible inline feedback; the correct answer unlocks **Try a challenge**.
- Incorrect answers remain retryable and include a hint rather than a dead end.
- Try a challenge opens Code Challenge.

### 4. Code Challenge
Purpose: Simulate a beginner-friendly coding task without implementing a real interpreter.

Content:
- Challenge header, XP reward, and progress indicator.
- Prompt: create `snack` and `quantity` variables so Pip can pack trail food.
- Expected concepts and a collapsible hint.
- Compact faux editor with line numbers and a prefilled editable `<textarea>` using monospace styling.
- **Run code** and **Submit quest** controls.
- Output console panel.

Interactions and deterministic validation:
- Run code inspects the text for assignments to `snack` and `quantity`; output changes to a friendly preview or a targeted hint.
- Submit succeeds when both assignments exist and `quantity` contains a numeric value; otherwise it shows specific, non-destructive guidance.
- Success opens an in-screen celebration panel/modal with Pip cheering, `+50 XP`, and actions for **View progress** or **Back to map**.
- Include a **Reset code** text action.
- This is explicitly a guided prototype validator, not arbitrary Python execution.

### 5. Progress
Purpose: Make effort and advancement feel rewarding.

Content:
- Level card showing **Seedling Coder · Level 3** and XP to next level.
- Seven-day activity row with the current streak.
- Skill-growth bars for Syntax, Variables, Logic, and Debugging.
- Recent achievement badges with original iconography: First Sprout, Bug Finder, and Three-Day Streak.
- Recent activity list tied to the lesson/challenge flow.
- Pip celebration/helper panel that changes after successful submission during the session.

Interactions:
- Badge selection reveals a compact detail panel.
- A **Continue learning** action returns to Course Map or the current Lesson.

### 6. Profile / Settings
Purpose: Provide a complete account destination and prototype preferences.

Content:
- Avatar, learner name, level, and join date.
- Goal card with a selectable daily target (5, 10, or 15 minutes).
- Preference toggles for sound effects, reduced motion, and lesson reminders.
- Course summary and a “Reset prototype progress” control.
- Small “About PySprout” block.

Interactions:
- Goal and toggles update local state and visibly persist while the app remains open.
- Reduced-motion setting also disables app-level decorative animation in addition to honoring the OS preference.
- Reset requires a confirmation panel and then restores the initial demo state.

## Navigation and State Model
- Keep the prototype dependency-light and use a top-level `Screen` union in React rather than adding a router package.
- `App` owns the current screen and shared prototype state: selected answer, lesson completion, challenge code/output/status, XP, badge detail, daily goal, preferences, toast, and reset confirmation.
- Use small typed data arrays for navigation items, course nodes, stats, skills, and badges to keep repeated rendering consistent.
- Contextual screens (Lesson and Challenge) use their own back controls; the persistent bottom navigation covers Home, Path, Learn/current lesson, Progress, and Profile.
- On screen changes, move focus to the new screen heading (or use a focusable main region) and scroll to the top for accessible SPA-style navigation.
- No localStorage is necessary; “persist” means within the current browser session/component lifetime.

## Component Structure
Keep the implementation focused in `src/App.tsx`, extracting reusable components within that file unless it becomes unwieldy:
- `AppShell`
- `TopBar`
- `BottomNav`
- `ForestBackdrop`
- `PipMascot` with expression/pose props
- `ProgressRing` / `ProgressBar`
- `StatPill`
- `CodeBlock`
- `Toast`
- `CelebrationPanel`
- One component per screen: `HomeScreen`, `CourseMapScreen`, `LessonScreen`, `ChallengeScreen`, `ProgressScreen`, `ProfileScreen`

Use inline SVG for Pip, navigation icons, badges, leaves, stars, and simple decorative elements. Add labels or `aria-hidden` appropriately depending on whether an SVG conveys meaning.

## File Changes

### `src/App.tsx`
- Replace the empty component with the complete typed six-screen React prototype.
- Add all app state, mock content, reusable UI pieces, original SVG art, screen components, validation logic, and navigation behavior.
- Keep all buttons as real `<button>` elements with explicit accessible labels where icon-only.

### `src/index.css`
- Keep CSS imports first and add the Nunito Google Fonts CSS2 import before the Tailwind import.
- Define theme tokens/custom properties for cream, evergreen, moss, mint, gold, coral, borders, and shadows.
- Set global typography, body background, selection color, focus-visible treatment, and basic form inheritance.
- Add only the custom styles that are awkward as utilities: forest backdrop layers, subtle float/celebration motion, code editor scrollbar, bottom safe-area spacing, and reduced-motion overrides.

No additional source files or dependencies are planned unless implementation size makes a small component split clearly safer.

## Responsive Behavior
- Mobile is the primary layout: edge-to-edge app shell, sticky bottom navigation, single-column cards, touch targets at least 44px, and safe-area padding.
- At tablet widths, use wider cards and selected two-column arrangements for dashboard/progress content.
- At desktop widths, center the experience in a generous max-width canvas with a slim left-side navigation replacing the bottom bar, while preserving the illustrated forest background and avoiding a stretched phone mockup appearance.
- Ensure the faux editor and long code lines scroll horizontally without widening the page.

## Accessibility and UX Details
- Maintain readable contrast over cream and dark green surfaces.
- Provide visible keyboard focus for every interactive control.
- Do not communicate locked/completed/correct states by color alone; pair color with icons and text.
- Use `aria-live` for answer feedback, run output, toast messages, and challenge completion.
- Label toggle controls and expose their checked state.
- Keep mascot art decorative when nearby text already conveys the message.
- Disable or simplify animation under OS or in-app reduced-motion preference.

## Verification
Because this is a broad UI replacement rather than a localized edit:
1. Run the repository formatter with `pnpm format`.
2. Run `pnpm build` and resolve any TypeScript, JSX, or CSS build errors.
3. Inspect the existing hot-reloaded preview at representative mobile and desktop widths.
4. Manually verify:
   - Every navigation destination is reachable.
   - Home → Lesson → correct answer → Challenge → run → submit → Progress works.
   - Incorrect lesson answers and incomplete challenge code show useful retry states.
   - Locked course nodes show feedback without navigation.
   - Profile settings update, reduced motion is respected, and reset confirmation works.
   - Keyboard focus, text wrapping, safe-area spacing, and editor overflow behave correctly.
   - No uploaded HackRU branding/art is included in the shipped UI.

## Out of Scope
- Real Python execution or sandboxing.
- Backend accounts, authentication, cloud persistence, reminders, analytics, or multiplayer features.
- A complete Python curriculum beyond the visible prototype course map.
- Reuse of the uploaded image as an application asset.
