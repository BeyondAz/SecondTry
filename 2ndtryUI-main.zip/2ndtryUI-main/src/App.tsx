import { useEffect, useRef, useState } from "react"

type Screen = "home" | "map" | "lesson" | "challenge" | "progress" | "profile"
type IconName = "home" | "map" | "play" | "chart" | "user" | "flame" | "star" | "clock" | "arrow" | "lock" | "check" | "code" | "book" | "leaf" | "trophy" | "bug" | "target" | "bell" | "volume" | "motion" | "chevron"

const initialCode = '# Pack Pip\'s trail snack\nsnack = ""\nquantity = 0'

const navItems: { id: Screen label: string icon: IconName }[] = [
  { id: "home", label: "Home", icon: "home" },
  { id: "map", label: "Path", icon: "map" },
  { id: "lesson", label: "Learn", icon: "play" },
  { id: "progress", label: "Progress", icon: "chart" },
  { id: "profile", label: "Profile", icon: "user" },
]

const screenTitles: Record<Screen, string> = {
  home: "Home",
  map: "Course path",
  lesson: "Variables lesson",
  challenge: "Trail snack challenge",
  progress: "Your progress",
  profile: "Profile and settings",
}

function Icon({
  name,
  size = 20,
  className = "",
}: {
  name: IconName
  size?: number
  className?: string
}) {
  const paths: Record<IconName, React.ReactNode> = {
    home: (
      <>
        <path d="M3 10.8 12 3l9 7.8" />
        <path d="M5.5 9.2V21h13V9.2M9 21v-7h6v7" />
      </>
    ),
    map: (
      <>
        <path d="m3 6 5-3 8 3 5-3v15l-5 3-8-3-5 3Z" />
        <path d="M8 3v15M16 6v15" />
      </>
    ),
    play: <path d="m9 7 8 5-8 5Z" />,
    chart: (
      <>
        <path d="M4 20V10M10 20V4M16 20v-7M22 20H2" />
      </>
    ),
    user: (
      <>
        <circle cx="12" cy="8" r="4" />
        <path d="M4.5 21a7.5 7.5 0 0 1 15 0" />
      </>
    ),
    flame: (
      <path d="M13.5 2.5c.5 4-2.5 5-1.5 8 1-1 2-2 2-4 3 2 5 5 5 8.5a7 7 0 1 1-14 0c0-3 1.5-5.5 4.5-8-.2 3 1 4 2 4.5-.5-3 1-5.5 2-9Z" />
    ),
    star: (
      <path d="m12 2.5 2.9 5.9 6.5.9-4.7 4.6 1.1 6.5-5.8-3-5.8 3 1.1-6.5-4.7-4.6 6.5-.9Z" />
    ),
    clock: (
      <>
        <circle cx="12" cy="12" r="9" />
        <path d="M12 7v5l3.5 2" />
      </>
    ),
    arrow: (
      <>
        <path d="M5 12h14M14 7l5 5-5 5" />
      </>
    ),
    lock: (
      <>
        <rect x="5" y="10" width="14" height="11" rx="3" />
        <path d="M8 10V7a4 4 0 0 1 8 0v3" />
      </>
    ),
    check: <path d="m5 12 4.2 4.2L19 6.5" />,
    code: (
      <>
        <path d="m8 8-4 4 4 4M16 8l4 4-4 4M14 4l-4 16" />
      </>
    ),
    book: (
      <>
        <path d="M4 4.5A3.5 3.5 0 0 1 7.5 1H11v18H7.5A3.5 3.5 0 0 0 4 22.5ZM20 4.5A3.5 3.5 0 0 0 16.5 1H13v18h3.5a3.5 3.5 0 0 1 3.5 3.5Z" />
      </>
    ),
    leaf: (
      <>
        <path d="M20.5 3.5C12 3 5 7 5 14c0 3.5 2.5 6 6 6 7 0 9-8 9.5-16.5Z" />
        <path d="M4 21c3-5 7-8 13-11" />
      </>
    ),
    trophy: (
      <>
        <path d="M8 4h8v5a4 4 0 0 1-8 0Z" />
        <path d="M8 6H4v2a4 4 0 0 0 4 4M16 6h4v2a4 4 0 0 1-4 4M12 13v5M8 21h8M9 18h6" />
      </>
    ),
    bug: (
      <>
        <ellipse cx="12" cy="13" rx="6" ry="8" />
        <path d="M9 5V3M15 5V3M6 10H3M6 15H3M18 10h3M18 15h3M9 10h6M9 15h6" />
      </>
    ),
    target: (
      <>
        <circle cx="12" cy="12" r="9" />
        <circle cx="12" cy="12" r="5" />
        <circle cx="12" cy="12" r="1" />
      </>
    ),
    bell: (
      <>
        <path d="M18 9a6 6 0 0 0-12 0c0 7-3 7-3 9h18c0-2-3-2-3-9ZM10 21h4" />
      </>
    ),
    volume: (
      <>
        <path d="M4 10v4h4l5 4V6L8 10ZM17 9a4 4 0 0 1 0 6M20 6a8 8 0 0 1 0 12" />
      </>
    ),
    motion: (
      <>
        <circle cx="12" cy="12" r="3" />
        <path d="M12 2v4M12 18v4M2 12h4M18 12h4M5 5l3 3M16 16l3 3M19 5l-3 3M8 16l-3 3" />
      </>
    ),
    chevron: <path d="m9 5 7 7-7 7" />,
  }

  return (
    <svg
      aria-hidden="true"
      className={className}
      fill="none"
      height={size}
      viewBox="0 0 24 24"
      width={size}
    >
      <g
        stroke="currentColor"
        strokeLinecap="round"
        strokeLinejoin="round"
        strokeWidth="2"
      >
        {paths[name]}
      </g>
    </svg>
  )
}

function PipMascot({
  mood = "happy",
  className = "",
}: {
  mood?: "happy" | "thinking" | "cheering" | "celebrating"
  className?: string
}) {
  const happy = mood === "happy"
  const thinking = mood === "thinking"
  const armsUp = mood === "cheering" || mood === "celebrating"

  return (
    <svg
      aria-hidden="true"
      className={`pip-mascot ${className}`}
      viewBox="0 0 180 190"
    >
      {mood === "celebrating" && (
        <g className="pip-confetti">
          <path d="m20 39 9 4-7 6Z" fill="#f6bd49" />
          <path d="m153 30 8-6 3 10Z" fill="#ef806d" />
          <path d="m148 74 11 2-5 8Z" fill="#b7d552" />
          <circle cx="35" cy="78" fill="#8cc6a5" r="5" />
        </g>
      )}
      <ellipse cx="90" cy="174" fill="#173e31" opacity=".13" rx="47" ry="9" />
      <path
        d="M87 49C72 31 74 13 87 8c12 7 16 24 6 40Z"
        fill="#8fbd4e"
        stroke="#234b38"
        strokeWidth="5"
      />
      <path
        d="M91 48c12-19 27-23 38-15-1 14-14 24-34 22Z"
        fill="#b5d75f"
        stroke="#234b38"
        strokeWidth="5"
      />
      <path
        d="M90 50c-1-15-9-25-24-29-7 14 2 29 21 34Z"
        fill="#6ea84e"
        stroke="#234b38"
        strokeWidth="5"
      />
      <path
        d="M56 95c-15-8-25-3-31 9M124 95c15-8 25-3 31 9"
        fill="none"
        stroke="#234b38"
        strokeLinecap="round"
        strokeWidth="8"
        transform={
          armsUp
            ? "rotate(18 56 95)"
            : thinking
              ? "rotate(-9 56 95)"
              : undefined
        }
      />
      <path
        d="M53 112c-2-42 14-66 38-66s41 24 38 66c-2 37-14 56-38 56s-36-19-38-56Z"
        fill="#d8e795"
        stroke="#234b38"
        strokeWidth="6"
      />
      <path
        d="M61 121c4 29 14 42 30 42 17 0 27-14 31-42-15 8-46 8-61 0Z"
        fill="#a9ce65"
        opacity=".7"
      />
      <ellipse cx="73" cy="98" fill="#173e31" rx="8" ry="11" />
      <ellipse cx="109" cy="98" fill="#173e31" rx="8" ry="11" />
      <circle cx="76" cy="94" fill="white" r="3" />
      <circle cx="112" cy="94" fill="white" r="3" />
      <ellipse cx="65" cy="114" fill="#ef8e82" opacity=".75" rx="8" ry="5" />
      <ellipse cx="117" cy="114" fill="#ef8e82" opacity=".75" rx="8" ry="5" />
      {thinking ? (
        <path
          d="M87 119c3-2 6-2 9 0"
          fill="none"
          stroke="#234b38"
          strokeLinecap="round"
          strokeWidth="4"
        />
      ) : (
        <path
          d={happy ? "M82 117c5 7 13 7 18 0" : "M80 116c6 10 15 10 22 0"}
          fill="#fff7dc"
          stroke="#234b38"
          strokeLinecap="round"
          strokeLinejoin="round"
          strokeWidth="4"
        />
      )}
      <path
        d="M64 148c-7 1-13 5-16 12M118 148c7 1 13 5 16 12"
        fill="none"
        stroke="#234b38"
        strokeLinecap="round"
        strokeWidth="7"
      />
      <path
        d="M115 126v26c-9 8-39 8-48 0v-26"
        fill="#e8a74c"
        stroke="#234b38"
        strokeLinejoin="round"
        strokeWidth="5"
      />
      <path
        d="M67 133c14 6 34 6 48 0M91 134v23"
        fill="none"
        stroke="#234b38"
        strokeWidth="4"
      />
    </svg>
  )
}

function ProgressBar({
  value,
  dark = false,
}: {
  value: number
  dark?: boolean
}) {
  return (
    <div
      className={`h-2.5 overflow-hidden rounded-full ${
        dark ? "bg-white/15" : "bg-[#dfe7ce]"
      }`}
    >
      <div
        className={`h-full rounded-full transition-all duration-500 ${
          dark ? "bg-[#d5ef83]" : "bg-[#74a64a]"
        }`}
        style={{ width: `${value}%` }}
      />
    </div>
  )
}

function ForestBackdrop() {
  return (
    <div aria-hidden="true" className="forest-backdrop">
      <span className="glow glow-one" />
      <span className="glow glow-two" />
      <svg className="canopy canopy-left" viewBox="0 0 320 720">
        <path d="M0 0h208c-10 76-59 90-63 159-6 92 66 100 38 191-19 62-92 57-84 140 5 54 38 104 11 230H0Z" />
        <path
          d="M0 52c80 21 107 57 89 108-16 46-55 70-89 74ZM0 363c59-20 106 17 90 69-12 39-50 58-90 56Z"
          opacity=".32"
        />
      </svg>
      <svg className="canopy canopy-right" viewBox="0 0 320 720">
        <path d="M320 0H112c10 76 59 90 63 159 6 92-66 100-38 191 19 62 92 57 84 140-5 54-38 104-11 230h110Z" />
        <path
          d="M320 84c-80 21-107 57-89 108 16 46 55 70 89 74ZM320 398c-59-20-106 17-90 69 12 39 50 58 90 56Z"
          opacity=".32"
        />
      </svg>
    </div>
  )
}

function TopBar({
  onHome,
  onProfile,
  xp,
}: {
  onHome: () => void
  onProfile: () => void
  xp: number
}) {
  return (
    <header className="flex items-center justify-between px-5 py-4 md:px-8">
      <button
        className="group flex items-center gap-2.5"
        onClick={onHome}
        aria-label="Go to PySprout home"
      >
        <span className="grid size-10 place-items-center rounded-2xl bg-[#d8eb8e] text-[#214a38] shadow-[0_4px_0_#214a38] transition-transform group-hover:-translate-y-0.5">
          <Icon name="leaf" size={23} />
        </span>
        <span className="text-xl font-black tracking-[-0.04em] text-[#173e31]">
          PySprout
        </span>
      </button>
      <div className="flex items-center gap-2">
        <span className="hidden items-center gap-1.5 rounded-full border border-[#dce4d1] bg-white/75 px-3 py-2 text-sm font-extrabold text-[#315544] sm:flex">
          <Icon className="text-[#e39a35]" name="star" size={17} />
          {xp} XP
        </span>
        <button
          aria-label="Open profile"
          className="grid size-11 place-items-center rounded-full border-2 border-white bg-[#efb76b] font-black text-[#254c3b] shadow-[0_3px_0_#c88b3d] transition-transform hover:-translate-y-0.5"
          onClick={onProfile}
        >
          M
        </button>
      </div>
    </header>
  )
}

function BottomNav({
  current,
  onNavigate,
}: {
  current: Screen
  onNavigate: (screen: Screen) => void
}) {
  return (
    <nav aria-label="Main navigation" className="bottom-nav lg:hidden">
      {navItems.map((item) => {
        const active =
          current === item.id ||
          (current === "challenge" && item.id === "lesson")
        const central = item.id === "lesson"
        return (
          <button
            aria-current={active ? "page" : undefined}
            className={`nav-button ${active ? "is-active" : ""} ${
              central ? "nav-button-central" : ""
            }`}
            key={item.id}
            onClick={() => onNavigate(item.id)}
          >
            <span className="nav-icon">
              <Icon name={item.icon} size={central ? 22 : 20} />
            </span>
            <span>{item.label}</span>
          </button>
        )
      })}
    </nav>
  )
}

function SideNav({
  current,
  onNavigate,
}: {
  current: Screen
  onNavigate: (screen: Screen) => void
}) {
  return (
    <nav
      aria-label="Main navigation"
      className="hidden w-56 shrink-0 flex-col gap-2 px-5 pb-8 pt-4 lg:flex"
    >
      <p className="mb-1 px-3 text-xs font-black uppercase tracking-[0.18em] text-[#789080]">
        Your grove
      </p>
      {navItems.map((item) => {
        const active =
          current === item.id ||
          (current === "challenge" && item.id === "lesson")
        return (
          <button
            aria-current={active ? "page" : undefined}
            className={`flex items-center gap-3 rounded-2xl px-4 py-3 text-left text-sm font-extrabold transition ${
              active
                ? "bg-[#214a38] text-white shadow-[0_4px_0_#133629]"
                : "text-[#527060] hover:bg-white/70"
            }`}
            key={item.id}
            onClick={() => onNavigate(item.id)}
          >
            <Icon name={item.icon} size={20} />
            {item.label}
          </button>
        )
      })}
      <div className="mt-auto overflow-hidden rounded-[24px] bg-[#dceca3] p-4 text-[#214a38]">
        <PipMascot className="-mb-6 -mt-5 ml-auto w-24" mood="happy" />
        <p className="relative text-sm font-black">
          Small steps grow strong roots.
        </p>
      </div>
    </nav>
  )
}

function SectionHeading({
  eyebrow,
  title,
  action,
}: {
  eyebrow?: string
  title: string
  action?: React.ReactNode
}) {
  return (
    <div className="mb-4 flex items-end justify-between gap-4">
      <div>
        {eyebrow && (
          <p className="mb-1 text-xs font-black uppercase tracking-[0.16em] text-[#6f8a78]">
            {eyebrow}
          </p>
        )}
        <h2 className="text-xl font-black tracking-[-0.03em] text-[#173e31]">
          {title}
        </h2>
      </div>
      {action}
    </div>
  )
}

function HomeScreen({
  onNavigate,
  xp,
  challengeComplete,
}: {
  onNavigate: (screen: Screen) => void
  xp: number
  challengeComplete: boolean
}) {
  return (
    <div className="screen-enter mx-auto max-w-5xl px-5 pb-8 md:px-8">
      <section className="hero-card relative overflow-hidden rounded-[30px] bg-[#214a38] px-6 py-7 text-white md:px-9 md:py-9">
        <div className="relative z-10 max-w-[67%] md:max-w-[62%]">
          <p className="mb-2 text-sm font-extrabold text-[#cfe790]">
            Good afternoon, Maya
          </p>
          <h1 className="max-w-xl text-3xl font-black leading-[1.05] tracking-[-0.045em] md:text-5xl">
            Ready to grow your Python skills?
          </h1>
          <p className="mt-3 max-w-md text-sm font-bold leading-6 text-white/70 md:text-base">
            Pip saved your spot. Your next quest is only eight minutes away.
          </p>
        </div>
        <PipMascot
          className="absolute -bottom-9 -right-7 w-44 rotate-[2deg] transition-transform duration-300 hover:-rotate-1 hover:scale-105 md:-bottom-11 md:right-3 md:w-60"
          mood="celebrating"
        />
        <span className="absolute -right-8 -top-10 size-40 rounded-full border-[28px] border-white/5" />
      </section>

      <div className="mt-5 grid gap-3 sm:grid-cols-3">
        {[
          {
            icon: "flame" as IconName,
            label: "Day streak",
            value: "4 days",
            color: "text-[#de7859]",
            bg: "bg-[#fff0e7]",
          },
          {
            icon: "star" as IconName,
            label: "Total XP",
            value: `${xp} XP`,
            color: "text-[#d5912d]",
            bg: "bg-[#fff5cf]",
          },
          {
            icon: "book" as IconName,
            label: "Lessons",
            value: challengeComplete ? "7 done" : "6 done",
            color: "text-[#628d43]",
            bg: "bg-[#edf4d5]",
          },
        ].map((stat) => (
          <div
            className="soft-card flex items-center gap-3 p-4"
            key={stat.label}
          >
            <span
              className={`grid size-11 place-items-center rounded-2xl ${stat.bg} ${stat.color}`}
            >
              <Icon name={stat.icon} />
            </span>
            <div>
              <p className="text-xs font-bold text-[#7a8e81]">{stat.label}</p>
              <p className="font-black text-[#244b3a]">{stat.value}</p>
            </div>
          </div>
        ))}
      </div>

      <section className="mt-8">
        <SectionHeading eyebrow="Keep growing" title="Continue your quest" />
        <div className="soft-card overflow-hidden">
          <div className="grid gap-0 md:grid-cols-[1.25fr_.75fr]">
            <div className="p-5 md:p-7">
              <div className="mb-4 flex items-center justify-between gap-3">
                <span className="rounded-full bg-[#e9f2c7] px-3 py-1.5 text-xs font-black uppercase tracking-wide text-[#54753a]">
                  Python foundations
                </span>
                <span className="flex items-center gap-1.5 text-xs font-extrabold text-[#74887a]">
                  <Icon name="clock" size={16} /> 8 min
                </span>
              </div>
              <h3 className="text-2xl font-black tracking-[-0.035em] text-[#173e31]">
                Variables &amp; types
              </h3>
              <p className="mt-2 text-sm font-semibold leading-6 text-[#6d8073]">
                Learn how to give your data a name, then pack Pip’s trail snack
                with code.
              </p>
              <div className="mt-5">
                <div className="mb-2 flex justify-between text-xs font-extrabold text-[#617568]">
                  <span>Lesson progress</span>
                  <span>60%</span>
                </div>
                <ProgressBar value={60} />
              </div>
              <button
                className="primary-button mt-5"
                onClick={() => onNavigate("lesson")}
              >
                Continue lesson <Icon name="arrow" size={18} />
              </button>
            </div>
            <div className="relative min-h-44 overflow-hidden bg-[#e7efbd]">
              <div className="absolute inset-0 opacity-30 forest-lines" />
              <PipMascot
                className="absolute -bottom-7 left-1/2 w-40 -translate-x-1/2"
                mood="thinking"
              />
            </div>
          </div>
        </div>
      </section>

      <section className="mt-8">
        <SectionHeading
          eyebrow="Three small wins"
          title="Today’s quests"
          action={
            <button
              className="text-sm font-extrabold text-[#50793b]"
              onClick={() => onNavigate("map")}
            >
              View path
            </button>
          }
        />
        <div className="space-y-3">
          {[
            {
              icon: "check" as IconName,
              title: "Review: Hello, Python",
              detail: "5 min · Complete",
              done: true,
              target: "lesson" as Screen,
            },
            {
              icon: "book" as IconName,
              title: "Learn: Variables & types",
              detail: "8 min · In progress",
              done: false,
              target: "lesson" as Screen,
            },
            {
              icon: "code" as IconName,
              title: "Challenge: Trail snacks",
              detail: `50 XP · ${challengeComplete ? "Complete" : "Ready"}`,
              done: challengeComplete,
              target: "challenge" as Screen,
            },
          ].map((quest) => (
            <button
              className="soft-card group flex w-full items-center gap-4 p-4 text-left transition hover:-translate-y-0.5"
              key={quest.title}
              onClick={() => onNavigate(quest.target)}
            >
              <span
                className={`grid size-11 shrink-0 place-items-center rounded-2xl ${
                  quest.done
                    ? "bg-[#dceca6] text-[#50743a]"
                    : "bg-[#f2ebcf] text-[#8a713e]"
                }`}
              >
                <Icon name={quest.icon} />
              </span>
              <span className="min-w-0 flex-1">
                <span className="block font-black text-[#284d3d]">
                  {quest.title}
                </span>
                <span className="mt-0.5 block text-xs font-bold text-[#829187]">
                  {quest.detail}
                </span>
              </span>
              <Icon
                className="text-[#96a39a] transition-transform group-hover:translate-x-1"
                name="chevron"
              />
            </button>
          ))}
        </div>
      </section>
    </div>
  )
}

const courseNodes = [
  { title: "Hello, Python", meta: "Lesson · 5 min", state: "done" },
  { title: "Variables & types", meta: "Lesson · 8 min", state: "current" },
  { title: "Strings in the wild", meta: "Lesson · 10 min", state: "open" },
  {
    title: "Trail snack challenge",
    meta: "Challenge · 50 XP",
    state: "challenge",
  },
]

function CourseMapScreen({
  onNavigate,
  onLocked,
}: {
  onNavigate: (screen: Screen) => void
  onLocked: () => void
}) {
  return (
    <div className="screen-enter mx-auto max-w-4xl px-5 pb-10 md:px-8">
      <div className="mb-7 flex items-start justify-between gap-5">
        <div>
          <p className="text-xs font-black uppercase tracking-[0.16em] text-[#6e8878]">
            Your learning path
          </p>
          <h1 className="mt-1 text-3xl font-black tracking-[-0.045em] text-[#173e31] md:text-4xl">
            Python Foundations
          </h1>
          <p className="mt-2 max-w-xl text-sm font-semibold leading-6 text-[#6d8073]">
            Follow the woodland trail from your first line of code to your first
            tiny project.
          </p>
        </div>
        <div className="hidden size-20 place-items-center rounded-full bg-[#e8f1c7] text-center sm:grid">
          <span>
            <strong className="block text-xl text-[#31583f]">28%</strong>
            <span className="text-[10px] font-black uppercase tracking-wide text-[#799079]">
              grown
            </span>
          </span>
        </div>
      </div>

      <div className="soft-card overflow-hidden p-5 md:p-8">
        <div className="mb-7 rounded-[22px] bg-[#244b3a] p-5 text-white">
          <div className="flex items-center justify-between gap-4">
            <div>
              <p className="text-xs font-black uppercase tracking-widest text-[#cde58a]">
                Chapter 1
              </p>
              <h2 className="mt-1 text-xl font-black">Planting the basics</h2>
            </div>
            <span className="grid size-12 place-items-center rounded-2xl bg-white/10 text-[#d8ec9c]">
              <Icon name="leaf" size={26} />
            </span>
          </div>
          <div className="mt-4">
            <ProgressBar dark value={40} />
          </div>
        </div>

        <div className="relative mx-auto max-w-xl pl-3">
          <div className="absolute bottom-9 left-[33px] top-9 w-1 rounded-full bg-[#d9e5c2]" />
          <div className="space-y-5">
            {courseNodes.map((node, index) => (
              <button
                className="group relative flex w-full items-center gap-5 text-left"
                key={node.title}
                onClick={() =>
                  onNavigate(
                    node.state === "challenge" ? "challenge" : "lesson",
                  )
                }
              >
                <span
                  className={`relative z-10 grid size-11 shrink-0 place-items-center rounded-full border-4 border-[#fbfaf2] shadow-[0_3px_0_#b7c7a7] ${
                    node.state === "done"
                      ? "bg-[#7da955] text-white"
                      : node.state === "current"
                        ? "bg-[#f1b65d] text-[#244b3a] ring-4 ring-[#f7e4ba]"
                        : "bg-[#e5edcd] text-[#648051]"
                  }`}
                >
                  {node.state === "done" ? (
                    <Icon name="check" size={18} />
                  ) : (
                    <span className="text-sm font-black">{index + 1}</span>
                  )}
                </span>
                <span
                  className={`min-w-0 flex-1 rounded-[20px] border p-4 transition group-hover:-translate-y-0.5 ${
                    node.state === "current"
                      ? "border-[#e6c374] bg-[#fff6d9] shadow-[0_4px_0_#e8d6a3]"
                      : "border-[#e0e7d8] bg-white/70 shadow-[0_3px_0_#dce4d5]"
                  }`}
                >
                  <span className="flex items-center justify-between gap-3">
                    <strong className="text-sm text-[#284d3d]">
                      {node.title}
                    </strong>
                    {node.state === "current" && (
                      <span className="rounded-full bg-[#f0b456] px-2.5 py-1 text-[10px] font-black uppercase tracking-wide text-[#264c3b]">
                        Next up
                      </span>
                    )}
                  </span>
                  <span className="mt-1 block text-xs font-bold text-[#849288]">
                    {node.meta}
                  </span>
                </span>
              </button>
            ))}
          </div>
          <PipMascot
            className="absolute -right-24 top-20 hidden w-24 xl:block"
            mood="cheering"
          />
        </div>

        <div className="mt-9 grid gap-3 sm:grid-cols-2">
          {[
            "Decisions & branches",
            "Loops & patterns",
            "Functions that help",
            "Your first tiny project",
          ].map((chapter, index) => (
            <button
              className="flex items-center gap-3 rounded-[20px] border border-dashed border-[#ccd8c2] bg-[#f6f6ed] p-4 text-left text-[#7f9084]"
              key={chapter}
              onClick={onLocked}
            >
              <span className="grid size-9 place-items-center rounded-xl bg-[#e6eadf]">
                <Icon name="lock" size={16} />
              </span>
              <span>
                <span className="block text-[10px] font-black uppercase tracking-wider">
                  Chapter {index + 2}
                </span>
                <strong className="text-sm">{chapter}</strong>
              </span>
            </button>
          ))}
        </div>
      </div>
    </div>
  )
}

function BackButton({
  onClick,
  label = "Back to path",
}: {
  onClick: () => void
  label?: string
}) {
  return (
    <button
      className="mb-5 flex items-center gap-2 text-sm font-extrabold text-[#5c7666] hover:text-[#244b3a]"
      onClick={onClick}
    >
      <span className="rotate-180">
        <Icon name="arrow" size={17} />
      </span>
      {label}
    </button>
  )
}

function LessonScreen({
  answer,
  setAnswer,
  checked,
  onCheck,
  onNavigate,
}: {
  answer: string
  setAnswer: (value: string) => void
  checked: boolean
  onCheck: () => void
  onNavigate: (screen: Screen) => void
}) {
  const correct = checked && answer === "level"
  const wrong = checked && answer !== "level"
  return (
    <div className="screen-enter mx-auto max-w-4xl px-5 pb-10 md:px-8">
      <BackButton onClick={() => onNavigate("map")} />
      <div className="mb-5 flex items-center gap-2">
        {[1, 2, 3, 4].map((step) => (
          <span
            className={`h-2 flex-1 rounded-full ${
              step < 4 ? "bg-[#7fa955]" : "bg-[#dfe7d5]"
            }`}
            key={step}
          />
        ))}
      </div>
      <article className="soft-card overflow-hidden">
        <div className="grid md:grid-cols-[1fr_230px]">
          <div className="p-5 md:p-8">
            <span className="rounded-full bg-[#e9f1c9] px-3 py-1.5 text-xs font-black uppercase tracking-wider text-[#55783d]">
              Lesson 2 of 4
            </span>
            <h1 className="mt-5 text-3xl font-black leading-tight tracking-[-0.045em] text-[#173e31] md:text-4xl">
              Give your data a name
            </h1>
            <p className="mt-4 font-semibold leading-7 text-[#5f7667]">
              A variable is like a labeled jar. The label helps Python remember
              what you put inside, so you can use it again later.
            </p>
            <div className="code-block mt-6">
              <div className="code-dots">
                <span />
                <span />
                <span />
              </div>
              <pre>
                <code>
                  <span className="code-name">player_name</span> ={" "}
                  <span className="code-string">"Maya"</span>
                  {"\n"}
                  <span className="code-name">level</span> ={" "}
                  <span className="code-number">1</span>
                  {"\n"}
                  <span className="code-name">ready</span> ={" "}
                  <span className="code-bool">True</span>
                </code>
              </pre>
            </div>
            <div className="mt-5 flex flex-wrap gap-2">
              {[
                ["string", '"Maya"'],
                ["integer", "1"],
                ["boolean", "True"],
              ].map(([type, value]) => (
                <span
                  className="rounded-full border border-[#dbe4d3] bg-[#f7f8ef] px-3 py-2 text-xs font-extrabold text-[#536b5c]"
                  key={type}
                >
                  <strong className="text-[#31583f]">{type}</strong> · {value}
                </span>
              ))}
            </div>
          </div>
          <aside className="relative flex min-h-52 items-end overflow-hidden bg-[#e6efbc] px-5 pt-5">
            <div className="absolute left-4 top-4 max-w-[150px] rounded-[18px] rounded-bl-sm bg-white/80 p-3 text-xs font-bold leading-5 text-[#46604f]">
              Names can use letters, numbers, and underscores.
            </div>
            <PipMascot className="-mb-6 ml-auto w-36" mood="thinking" />
          </aside>
        </div>
      </article>

      <section className="soft-card mt-5 p-5 md:p-8">
        <SectionHeading
          eyebrow="Quick check"
          title="Which variable stores a number?"
        />
        <div className="grid gap-3">
          {[
            { value: "player_name", code: 'player_name = "Maya"' },
            { value: "level", code: "level = 1" },
            { value: "ready", code: "ready = True" },
          ].map((option) => {
            const selected = answer === option.value
            const isCorrect = checked && option.value === "level"
            const isWrong = checked && selected && option.value !== "level"
            return (
              <button
                className={`flex items-center gap-3 rounded-[18px] border-2 p-4 text-left font-mono text-sm font-bold transition ${
                  isCorrect
                    ? "border-[#7ca453] bg-[#edf5d8]"
                    : isWrong
                      ? "border-[#dd8872] bg-[#fff0e9]"
                      : selected
                        ? "border-[#e2b95e] bg-[#fff7dc]"
                        : "border-[#e0e6db] bg-white hover:border-[#a8bd92]"
                }`}
                key={option.value}
                onClick={() => setAnswer(option.value)}
              >
                <span
                  className={`grid size-6 shrink-0 place-items-center rounded-full border-2 ${
                    selected
                      ? "border-[#31583f] bg-[#31583f] text-white"
                      : "border-[#bcc9b5]"
                  }`}
                >
                  {selected && (
                    <span className="size-2 rounded-full bg-white" />
                  )}
                </span>
                {option.code}
                {isCorrect && (
                  <Icon
                    className="ml-auto text-[#5e893f]"
                    name="check"
                    size={20}
                  />
                )}
              </button>
            )
          })}
        </div>
        <div aria-live="polite" className="mt-4 min-h-6">
          {correct && (
            <p className="flex items-center gap-2 text-sm font-extrabold text-[#547c3b]">
              <Icon name="check" size={18} /> Exactly. Integers are whole
              numbers, like 1.
            </p>
          )}
          {wrong && (
            <p className="text-sm font-extrabold text-[#ad5e4d]">
              Not quite. Look for the value without quotes and without True or
              False.
            </p>
          )}
        </div>
        <div className="mt-4 flex flex-col gap-3 sm:flex-row">
          {!correct ? (
            <button
              className="primary-button sm:ml-auto"
              disabled={!answer}
              onClick={onCheck}
            >
              Check answer
            </button>
          ) : (
            <button
              className="primary-button sm:ml-auto"
              onClick={() => onNavigate("challenge")}
            >
              Try a challenge <Icon name="arrow" size={18} />
            </button>
          )}
        </div>
      </section>
    </div>
  )
}

function ChallengeScreen({
  code,
  setCode,
  output,
  status,
  onRun,
  onSubmit,
  onReset,
  onNavigate,
}: {
  code: string
  setCode: (value: string) => void
  output: string
  status: "idle" | "ran" | "success" | "error"
  onRun: () => void
  onSubmit: () => void
  onReset: () => void
  onNavigate: (screen: Screen) => void
}) {
  const [hintOpen, setHintOpen] = useState(false)
  return (
    <div className="screen-enter mx-auto max-w-5xl px-5 pb-10 md:px-8">
      <BackButton label="Back to lesson" onClick={() => onNavigate("lesson")} />
      <div className="mb-5 flex items-center justify-between gap-3">
        <div>
          <p className="text-xs font-black uppercase tracking-[0.16em] text-[#6e8878]">
            Code challenge
          </p>
          <h1 className="mt-1 text-3xl font-black tracking-[-0.045em] text-[#173e31]">
            Pack a trail snack
          </h1>
        </div>
        <span className="flex items-center gap-1.5 rounded-full bg-[#fff2c4] px-3 py-2 text-sm font-black text-[#8f671e]">
          <Icon name="star" size={17} /> 50 XP
        </span>
      </div>

      <div className="grid gap-5 lg:grid-cols-[.8fr_1.2fr]">
        <section className="soft-card p-5 md:p-6">
          <div className="overflow-hidden rounded-[22px] bg-[#e5efba]">
            <PipMascot
              className="-mb-6 mx-auto w-40"
              mood={status === "success" ? "celebrating" : "happy"}
            />
          </div>
          <h2 className="mt-5 text-xl font-black text-[#234a39]">Your quest</h2>
          <p className="mt-2 text-sm font-semibold leading-6 text-[#687d6f]">
            Create a <code className="inline-code">snack</code> variable with a
            word inside quotes, then set{" "}
            <code className="inline-code">quantity</code> to a number.
          </p>
          <ul className="mt-4 space-y-2 text-sm font-bold text-[#526b5b]">
            <li className="flex gap-2">
              <Icon className="mt-0.5 text-[#7aa04f]" name="check" size={17} />{" "}
              Name both variables correctly
            </li>
            <li className="flex gap-2">
              <Icon className="mt-0.5 text-[#7aa04f]" name="check" size={17} />{" "}
              Store a number in quantity
            </li>
          </ul>
          <button
            className="mt-5 flex w-full items-center justify-between rounded-2xl bg-[#f3f2e7] px-4 py-3 text-left text-sm font-extrabold text-[#4d6858]"
            onClick={() => setHintOpen(!hintOpen)}
          >
            Need a hint?{" "}
            <span
              className={`transition-transform ${hintOpen ? "rotate-90" : ""}`}
            >
              <Icon name="chevron" size={17} />
            </span>
          </button>
          {hintOpen && (
            <p className="mt-3 rounded-2xl border border-[#dce4d2] p-3 text-xs font-bold leading-5 text-[#718277]">
              Try <code className="inline-code">snack = "berries"</code>. A text
              value needs quotation marks.
            </p>
          )}
        </section>

        <section className="overflow-hidden rounded-[26px] border border-[#173e31] bg-[#173e31] shadow-[0_7px_0_#0d2e23]">
          <div className="flex items-center justify-between border-b border-white/10 px-4 py-3 text-white">
            <div className="flex items-center gap-2 text-xs font-extrabold">
              <Icon name="code" size={17} /> main.py
            </div>
            <button
              className="text-xs font-bold text-white/60 hover:text-white"
              onClick={onReset}
            >
              Reset code
            </button>
          </div>
          <div className="code-editor-wrap">
            <div aria-hidden="true" className="line-numbers">
              1{"\n"}2{"\n"}3
            </div>
            <textarea
              aria-label="Python code editor"
              className="code-editor"
              onChange={(event) => setCode(event.target.value)}
              spellCheck={false}
              value={code}
            />
          </div>
          <div className="border-t border-white/10 bg-[#102f25] p-4">
            <div className="mb-2 flex items-center justify-between">
              <span className="text-[10px] font-black uppercase tracking-[0.16em] text-white/45">
                Output
              </span>
              <span
                className={`size-2 rounded-full ${
                  status === "error"
                    ? "bg-[#ef806d]"
                    : status === "idle"
                      ? "bg-white/20"
                      : "bg-[#acd268]"
                }`}
              />
            </div>
            <p
              aria-live="polite"
              className={`min-h-10 whitespace-pre-wrap font-mono text-xs leading-5 ${
                status === "error" ? "text-[#ffb2a1]" : "text-[#dbe8cf]"
              }`}
            >
              {output}
            </p>
          </div>
          <div className="flex gap-3 bg-[#173e31] p-4">
            <button className="secondary-dark-button flex-1" onClick={onRun}>
              Run code
            </button>
            <button className="accent-button flex-1" onClick={onSubmit}>
              Submit quest
            </button>
          </div>
        </section>
      </div>

      {status === "success" && (
        <div
          aria-live="polite"
          className="celebration-panel mt-6 overflow-hidden rounded-[28px] border-2 border-[#7da650] bg-[#eff6d5] p-5 md:p-7"
        >
          <div className="flex flex-col items-center gap-5 text-center sm:flex-row sm:text-left">
            <span className="grid size-16 shrink-0 place-items-center rounded-full bg-[#f3be59] text-[#234a39] shadow-[0_4px_0_#c99332]">
              <Icon name="trophy" size={30} />
            </span>
            <div className="flex-1">
              <p className="text-xs font-black uppercase tracking-widest text-[#6c8a4e]">
                Quest complete · +50 XP
              </p>
              <h2 className="mt-1 text-2xl font-black text-[#234a39]">
                Pip’s pack is ready!
              </h2>
              <p className="mt-1 text-sm font-semibold text-[#62765e]">
                You created two useful variables and picked the right data
                types.
              </p>
            </div>
            <div className="flex w-full gap-2 sm:w-auto sm:flex-col">
              <button
                className="primary-button flex-1"
                onClick={() => onNavigate("progress")}
              >
                View progress
              </button>
              <button
                className="text-button flex-1"
                onClick={() => onNavigate("map")}
              >
                Back to map
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

function ProgressScreen({
  xp,
  challengeComplete,
  onNavigate,
}: {
  xp: number
  challengeComplete: boolean
  onNavigate: (screen: Screen) => void
}) {
  const [selectedBadge, setSelectedBadge] = useState<string | null>(null)
  const skills = [
    ["Syntax", challengeComplete ? 76 : 68],
    ["Variables", challengeComplete ? 82 : 55],
    ["Logic", 38],
    ["Debugging", 44],
  ] as [string, number][]
  const badges = [
    {
      name: "First Sprout",
      icon: "leaf" as IconName,
      copy: "Completed your very first Python lesson.",
    },
    {
      name: "Bug Finder",
      icon: "bug" as IconName,
      copy: "Fixed a mistake and ran the code again.",
    },
    {
      name: "3-Day Streak",
      icon: "flame" as IconName,
      copy: "Learned for three days in a row.",
    },
  ]
  return (
    <div className="screen-enter mx-auto max-w-5xl px-5 pb-10 md:px-8">
      <div className="mb-7">
        <p className="text-xs font-black uppercase tracking-[0.16em] text-[#6e8878]">
          Your growth
        </p>
        <h1 className="mt-1 text-3xl font-black tracking-[-0.045em] text-[#173e31] md:text-4xl">
          Look how far you’ve grown
        </h1>
      </div>
      <div className="grid gap-5 md:grid-cols-[1.1fr_.9fr]">
        <section className="relative overflow-hidden rounded-[28px] bg-[#214a38] p-6 text-white md:p-8">
          <div className="relative z-10 max-w-[67%]">
            <p className="text-xs font-black uppercase tracking-[0.16em] text-[#cde58a]">
              Seedling coder
            </p>
            <h2 className="mt-2 text-3xl font-black">Level 3</h2>
            <p className="mt-2 text-sm font-semibold text-white/65">
              {350 - (xp % 350)} XP until your next level
            </p>
            <div className="mt-5">
              <ProgressBar dark value={Math.min(100, (xp % 350) / 3.5)} />
            </div>
          </div>
          <PipMascot
            className="absolute -bottom-8 -right-4 w-40"
            mood={challengeComplete ? "celebrating" : "cheering"}
          />
        </section>
        <section className="soft-card p-5 md:p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-xs font-black uppercase tracking-wider text-[#778b7e]">
                Current streak
              </p>
              <p className="mt-1 text-3xl font-black text-[#244b3a]">4 days</p>
            </div>
            <span className="grid size-12 place-items-center rounded-2xl bg-[#ffede4] text-[#dc765b]">
              <Icon name="flame" size={26} />
            </span>
          </div>
          <div className="mt-5 grid grid-cols-7 gap-1.5">
            {["M", "T", "W", "T", "F", "S", "S"].map((day, index) => (
              <div className="text-center" key={`${day}-${index}`}>
                <span
                  className={`mx-auto grid size-8 place-items-center rounded-full text-xs font-black ${
                    index < 4
                      ? "bg-[#81aa58] text-white"
                      : "bg-[#edf0e6] text-[#8a988f]"
                  }`}
                >
                  {index < 4 ? <Icon name="check" size={14} /> : day}
                </span>
                <span className="mt-1 block text-[9px] font-bold text-[#91a096]">
                  {day}
                </span>
              </div>
            ))}
          </div>
        </section>
      </div>

      <div className="mt-5 grid gap-5 md:grid-cols-2">
        <section className="soft-card p-5 md:p-6">
          <SectionHeading eyebrow="Skill garden" title="What’s taking root" />
          <div className="space-y-5">
            {skills.map(([skill, value]) => (
              <div key={skill}>
                <div className="mb-2 flex justify-between text-sm font-extrabold text-[#4d6757]">
                  <span>{skill}</span>
                  <span>{value}%</span>
                </div>
                <ProgressBar value={value} />
              </div>
            ))}
          </div>
        </section>
        <section className="soft-card p-5 md:p-6">
          <SectionHeading eyebrow="Achievement shelf" title="Badges earned" />
          <div className="grid grid-cols-3 gap-2">
            {badges.map((badge, index) => (
              <button
                className={`rounded-[20px] border p-3 text-center transition hover:-translate-y-1 ${
                  selectedBadge === badge.name
                    ? "border-[#ddae4c] bg-[#fff7da]"
                    : "border-[#e0e7da] bg-[#f9faf3]"
                }`}
                key={badge.name}
                onClick={() => setSelectedBadge(badge.name)}
              >
                <span
                  className={`mx-auto grid size-11 place-items-center rounded-2xl ${
                    index === 0
                      ? "bg-[#e5efbd] text-[#5e8542]"
                      : index === 1
                        ? "bg-[#d8ece5] text-[#38725c]"
                        : "bg-[#ffe8dd] text-[#ce6e55]"
                  }`}
                >
                  <Icon name={badge.icon} size={22} />
                </span>
                <span className="mt-2 block text-[11px] font-black leading-tight text-[#3e5b4a]">
                  {badge.name}
                </span>
              </button>
            ))}
          </div>
          <div
            aria-live="polite"
            className="mt-4 min-h-16 rounded-2xl bg-[#f1f3e8] p-3 text-xs font-bold leading-5 text-[#6a7e70]"
          >
            {selectedBadge
              ? badges.find((badge) => badge.name === selectedBadge)?.copy
              : "Select a badge to see how you earned it."}
          </div>
        </section>
      </div>

      <section className="soft-card mt-5 p-5 md:p-6">
        <SectionHeading eyebrow="Recent activity" title="Your latest wins" />
        <div className="divide-y divide-[#e6eadf]">
          {[
            [
              challengeComplete
                ? "Completed Trail snack challenge"
                : "Started Variables & types",
              challengeComplete ? "+50 XP" : "+10 XP",
              "code",
            ],
            ["Finished Hello, Python", "+30 XP", "check"],
            ["Earned a 3-day streak", "+15 XP", "flame"],
          ].map(([title, reward, icon]) => (
            <div
              className="flex items-center gap-3 py-3 first:pt-0 last:pb-0"
              key={title}
            >
              <span className="grid size-9 place-items-center rounded-xl bg-[#eef2df] text-[#668648]">
                <Icon name={icon as IconName} size={17} />
              </span>
              <span className="flex-1 text-sm font-extrabold text-[#466051]">
                {title}
              </span>
              <span className="text-xs font-black text-[#7a9b51]">
                {reward}
              </span>
            </div>
          ))}
        </div>
        <button
          className="primary-button mt-6"
          onClick={() => onNavigate("map")}
        >
          Continue learning <Icon name="arrow" size={18} />
        </button>
      </section>
    </div>
  )
}

function Toggle({
  checked,
  onChange,
  label,
  icon,
}: {
  checked: boolean
  onChange: () => void
  label: string
  icon: IconName
}) {
  return (
    <button
      aria-pressed={checked}
      className="flex w-full items-center gap-3 py-3 text-left"
      onClick={onChange}
    >
      <span className="grid size-10 place-items-center rounded-2xl bg-[#eef2e3] text-[#567649]">
        <Icon name={icon} size={19} />
      </span>
      <span className="flex-1 text-sm font-extrabold text-[#425e4e]">
        {label}
      </span>
      <span
        className={`relative h-7 w-12 rounded-full transition ${
          checked ? "bg-[#719b4c]" : "bg-[#cfd8ca]"
        }`}
      >
        <span
          className={`absolute top-1 size-5 rounded-full bg-white shadow transition-transform ${
            checked ? "translate-x-6" : "translate-x-1"
          }`}
        />
      </span>
    </button>
  )
}

function ProfileScreen({
  dailyGoal,
  setDailyGoal,
  preferences,
  setPreference,
  onReset,
}: {
  dailyGoal: number
  setDailyGoal: (value: number) => void
  preferences: { sound: boolean reducedMotion: boolean reminders: boolean }
  setPreference: (key: "sound" | "reducedMotion" | "reminders") => void
  onReset: () => void
}) {
  return (
    <div className="screen-enter mx-auto max-w-4xl px-5 pb-10 md:px-8">
      <div className="mb-7">
        <p className="text-xs font-black uppercase tracking-[0.16em] text-[#6e8878]">
          Your corner of the grove
        </p>
        <h1 className="mt-1 text-3xl font-black tracking-[-0.045em] text-[#173e31] md:text-4xl">
          Profile &amp; settings
        </h1>
      </div>
      <section className="relative overflow-hidden rounded-[28px] bg-[#214a38] p-6 text-white md:p-8">
        <div className="relative z-10 flex items-center gap-5">
          <span className="grid size-20 shrink-0 place-items-center rounded-full border-4 border-white/20 bg-[#efb76b] text-2xl font-black text-[#244b3a]">
            M
          </span>
          <div>
            <h2 className="text-2xl font-black">Maya Rivera</h2>
            <p className="mt-1 text-sm font-bold text-[#cce28f]">
              Seedling Coder · Level 3
            </p>
            <p className="mt-1 text-xs font-semibold text-white/50">
              Learning since March 2025
            </p>
          </div>
        </div>
        <span className="absolute -right-8 -top-12 size-44 rounded-full border-[32px] border-white/5" />
      </section>
      <div className="mt-5 grid gap-5 md:grid-cols-2">
        <section className="soft-card p-5 md:p-6">
          <SectionHeading eyebrow="Daily rhythm" title="Learning goal" />
          <p className="mb-4 text-sm font-semibold leading-6 text-[#718277]">
            How much time would you like to spend growing each day?
          </p>
          <div className="grid grid-cols-3 gap-2">
            {[5, 10, 15].map((goal) => (
              <button
                className={`rounded-[18px] border-2 px-2 py-4 text-center transition ${
                  dailyGoal === goal
                    ? "border-[#6e994b] bg-[#edf4d6] text-[#31583f]"
                    : "border-[#e1e7dc] text-[#718177] hover:border-[#aabc9c]"
                }`}
                key={goal}
                onClick={() => setDailyGoal(goal)}
              >
                <strong className="block text-xl">{goal}</strong>
                <span className="text-[10px] font-black uppercase tracking-wider">
                  minutes
                </span>
              </button>
            ))}
          </div>
          <div className="mt-5 flex items-center gap-3 rounded-2xl bg-[#fff5d8] p-3 text-xs font-bold leading-5 text-[#796331]">
            <Icon name="target" size={20} /> Your goal fits one short lesson a
            day.
          </div>
        </section>
        <section className="soft-card p-5 md:p-6">
          <SectionHeading eyebrow="Make it yours" title="Preferences" />
          <div className="divide-y divide-[#e5eae1]">
            <Toggle
              checked={preferences.sound}
              icon="volume"
              label="Sound effects"
              onChange={() => setPreference("sound")}
            />
            <Toggle
              checked={preferences.reducedMotion}
              icon="motion"
              label="Reduce motion"
              onChange={() => setPreference("reducedMotion")}
            />
            <Toggle
              checked={preferences.reminders}
              icon="bell"
              label="Lesson reminders"
              onChange={() => setPreference("reminders")}
            />
          </div>
        </section>
      </div>
      <section className="soft-card mt-5 p-5 md:p-6">
        <SectionHeading eyebrow="Course summary" title="Python Foundations" />
        <div className="grid gap-3 sm:grid-cols-3">
          {[
            ["28%", "course grown"],
            ["6", "lessons done"],
            ["4", "day streak"],
          ].map(([value, label]) => (
            <div
              className="rounded-[18px] bg-[#f3f5eb] p-4 text-center"
              key={label}
            >
              <strong className="block text-2xl text-[#31583f]">{value}</strong>
              <span className="text-xs font-bold text-[#849187]">{label}</span>
            </div>
          ))}
        </div>
      </section>
      <section className="mt-5 rounded-[24px] border border-[#e6d7d1] bg-[#fff8f3] p-5">
        <div className="flex flex-col justify-between gap-4 sm:flex-row sm:items-center">
          <div>
            <h2 className="font-black text-[#5d433b]">
              Reset prototype progress
            </h2>
            <p className="mt-1 text-xs font-semibold text-[#8c756d]">
              Restore the lesson, challenge, XP, and preferences to their demo
              defaults.
            </p>
          </div>
          <button
            className="rounded-full border-2 border-[#d88b77] px-4 py-2.5 text-sm font-black text-[#ae5f4c] transition hover:bg-[#fff0ea]"
            onClick={onReset}
          >
            Reset progress
          </button>
        </div>
      </section>
      <p className="mt-6 text-center text-xs font-bold text-[#89958d]">
        PySprout prototype · Made for curious beginners
      </p>
    </div>
  )
}

export default function App() {
  const [screen, setScreen] = useState<Screen>("home")
  const [answer, setAnswer] = useState("")
  const [answerChecked, setAnswerChecked] = useState(false)
  const [code, setCode] = useState(initialCode)
  const [output, setOutput] = useState("Run your code to see what Pip packs.")
  const [challengeStatus, setChallengeStatus] =
    useState<"idle" | "ran" | "success" | "error">("idle")
  const [challengeAwarded, setChallengeAwarded] = useState(false)
  const [xp, setXp] = useState(280)
  const [dailyGoal, setDailyGoal] = useState(10)
  const [preferences, setPreferences] = useState({
    sound: true,
    reducedMotion: false,
    reminders: true,
  })
  const [toast, setToast] = useState("")
  const [resetOpen, setResetOpen] = useState(false)
  const mainRef = useRef<HTMLElement>(null)

  const challengeComplete = challengeAwarded

  useEffect(() => {
    window.scrollTo({
      top: 0,
      behavior: preferences.reducedMotion ? "auto" : "smooth",
    })
    mainRef.current?.focus()
  }, [screen, preferences.reducedMotion])

  useEffect(() => {
    if (!toast) return
    const timer = window.setTimeout(() => setToast(""), 2600)
    return () => window.clearTimeout(timer)
  }, [toast])

  function navigate(next: Screen) {
    setScreen(next)
  }

  function validateCode(isSubmit: boolean) {
    const snackMatch = code.match(/^\s*snack\s*=\s*(.+)$/m)
    const quantityMatch = code.match(/^\s*quantity\s*=\s*(.+)$/m)
    const numericQuantity =
      quantityMatch && /^\s*-?\d+(\.\d+)?\s*$/.test(quantityMatch[1])

    if (!snackMatch && !quantityMatch) {
      setChallengeStatus("error")
      setOutput("I can’t find snack or quantity yet. Add both variable names.")
      return
    }
    if (!snackMatch) {
      setChallengeStatus("error")
      setOutput("Pip found the quantity, but still needs a snack variable.")
      return
    }
    if (!quantityMatch || !numericQuantity) {
      setChallengeStatus("error")
      setOutput("Set quantity to a number, like quantity = 3.")
      return
    }
    const snackValue = snackMatch[1].trim().replace(/^["']|["']$/g, "")
    if (isSubmit) {
      if (!challengeAwarded) {
        setXp((value) => value + 50)
        setChallengeAwarded(true)
      }
      setChallengeStatus("success")
      setOutput(
        `Packed ${quantityMatch[1].trim()} ${snackValue || "snacks"} for the trail. Quest complete!`,
      )
    } else {
      setChallengeStatus("ran")
      setOutput(
        `Pip will pack ${quantityMatch[1].trim()} ${snackValue || "snacks"}. Looking good!`,
      )
    }
  }

  function resetPrototype() {
    setScreen("home")
    setAnswer("")
    setAnswerChecked(false)
    setCode(initialCode)
    setOutput("Run your code to see what Pip packs.")
    setChallengeStatus("idle")
    setChallengeAwarded(false)
    setXp(280)
    setDailyGoal(10)
    setPreferences({ sound: true, reducedMotion: false, reminders: true })
    setResetOpen(false)
    setToast("Prototype progress reset")
  }

  return (
    <div
      className={
        preferences.reducedMotion
          ? "reduce-app-motion min-h-screen"
          : "min-h-screen"
      }
    >
      <ForestBackdrop />
      <div className="relative mx-auto min-h-screen max-w-[1380px]">
        <TopBar
          onHome={() => navigate("home")}
          onProfile={() => navigate("profile")}
          xp={xp}
        />
        <div className="flex">
          <SideNav current={screen} onNavigate={navigate} />
          <main
            aria-label={screenTitles[screen]}
            className="min-w-0 flex-1 pb-24 outline-none lg:pb-8"
            ref={mainRef}
            tabIndex={-1}
          >
            {screen === "home" && (
              <HomeScreen
                challengeComplete={challengeComplete}
                onNavigate={navigate}
                xp={xp}
              />
            )}
            {screen === "map" && (
              <CourseMapScreen
                onLocked={() => setToast("Finish the previous quest first")}
                onNavigate={navigate}
              />
            )}
            {screen === "lesson" && (
              <LessonScreen
                answer={answer}
                checked={answerChecked}
                onCheck={() => setAnswerChecked(true)}
                onNavigate={navigate}
                setAnswer={(value) => {
                  setAnswer(value)
                  setAnswerChecked(false)
                }}
              />
            )}
            {screen === "challenge" && (
              <ChallengeScreen
                code={code}
                onNavigate={navigate}
                onReset={() => {
                  setCode(initialCode)
                  setOutput("Code reset. Try a new snack!")
                  setChallengeStatus("idle")
                }}
                onRun={() => validateCode(false)}
                onSubmit={() => validateCode(true)}
                output={output}
                setCode={setCode}
                status={challengeStatus}
              />
            )}
            {screen === "progress" && (
              <ProgressScreen
                challengeComplete={challengeComplete}
                onNavigate={navigate}
                xp={xp}
              />
            )}
            {screen === "profile" && (
              <ProfileScreen
                dailyGoal={dailyGoal}
                onReset={() => setResetOpen(true)}
                preferences={preferences}
                setDailyGoal={setDailyGoal}
                setPreference={(key) =>
                  setPreferences((current) => ({
                    ...current,
                    [key]: !current[key],
                  }))
                }
              />
            )}
          </main>
        </div>
        <BottomNav current={screen} onNavigate={navigate} />
      </div>

      {toast && (
        <div aria-live="polite" className="toast-message">
          <Icon name="leaf" size={17} /> {toast}
        </div>
      )}

      {resetOpen && (
        <div aria-modal="true" className="modal-backdrop" role="dialog">
          <div className="modal-card">
            <span className="mx-auto grid size-14 place-items-center rounded-full bg-[#fff0e9] text-[#be6651]">
              <Icon name="target" size={26} />
            </span>
            <h2 className="mt-4 text-xl font-black text-[#244b3a]">
              Reset your progress?
            </h2>
            <p className="mt-2 text-sm font-semibold leading-6 text-[#718277]">
              This returns the prototype to its starting lesson, XP, and
              settings.
            </p>
            <div className="mt-5 flex gap-3">
              <button
                className="text-button flex-1"
                onClick={() => setResetOpen(false)}
              >
                Keep progress
              </button>
              <button
                className="rounded-full bg-[#c86e58] px-5 py-3 text-sm font-black text-white shadow-[0_4px_0_#9b4e3d]"
                onClick={resetPrototype}
              >
                Reset
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
